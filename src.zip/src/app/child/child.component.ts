import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  message='child Message';


  @Input()
  parentMessage='';
  @Output()
  childChanged=new EventEmitter<string>();
    

  constructor() { }

  ngOnInit() {
  }


  sendMessageToParent(){
    console.log("In setMessageToParent :"+this.message);
    this.childChanged.emit(this.message);
  }
}
