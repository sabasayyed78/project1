import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-nestingcomponent',
  templateUrl: './nestingcomponent.component.html',
  styleUrls: ['./nestingcomponent.component.css']
})
export class NestingcomponentComponent implements OnInit {
title='Nested Component Demo';
  constructor() { }

  ngOnInit() {
  }

}
