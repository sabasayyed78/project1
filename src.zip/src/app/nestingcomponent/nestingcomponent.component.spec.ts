import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NestingcomponentComponent } from './nestingcomponent.component';

describe('NestingcomponentComponent', () => {
  let component: NestingcomponentComponent;
  let fixture: ComponentFixture<NestingcomponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NestingcomponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NestingcomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
