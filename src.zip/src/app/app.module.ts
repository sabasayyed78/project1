import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GallaryComponent } from './gallary/gallary.component';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AccomodationComponent } from './accomodation/accomodation.component';
import { BlogComponent } from './blog/blog.component';
import { ContactComponent } from './contact/contact.component';
import { HighlightDirective } from './highlight.directive';
import { NestingcomponentComponent } from './nestingcomponent/nestingcomponent.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { StyleDirective } from './style.directive';


@NgModule({
  declarations: [
    AppComponent,
    GallaryComponent,
    HomeComponent,
    AboutusComponent,
    AccomodationComponent,
    BlogComponent,
    ContactComponent,
    HighlightDirective,
    NestingcomponentComponent,
    ParentComponent,
    ChildComponent,
    StyleDirective,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
