import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accomodation',
  templateUrl: './accomodation.component.html',
  styleUrls: ['./accomodation.component.css']
})
export class AccomodationComponent implements OnInit {
a:number = 350;
b:number = 250;
c:number = 750;
d:number = 200;

  constructor() { }

  ngOnInit() {
  }

}
