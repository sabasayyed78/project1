import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GallaryComponent } from './gallary/gallary.component';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AccomodationComponent } from './accomodation/accomodation.component';
import { BlogComponent } from './blog/blog.component';
import { ContactComponent } from './contact/contact.component';
import {  NestingcomponentComponent } from './nestingcomponent/nestingcomponent.component';





const routes: Routes = [
  {path:'gallary',component:GallaryComponent},
  {path:'',component:HomeComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'accomodation',component:AccomodationComponent},
  {path:'blog',component:BlogComponent},
  {path:'contact',component:ContactComponent},
  {path:'nestingcomponent',component:NestingcomponentComponent},
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
